const { Client } = require('discord.js-selfbot-v13');
const { joinVoiceChannel, createAudioPlayer, AudioPlayerStatus } = require('@discordjs/voice');

const token = process.argv[2];
const channelId = process.argv[3];

const client = new Client();
let connection = null;

client.once('ready', async () => {
  console.log(`Bot with token ${token} is ready!`);
  
  client.user.setStatus("idle");

  try {
    const channel = await client.channels.fetch(channelId);
    
    // Join the voice channel
    await joinChannel(channel);
  } catch (error) {
    console.error(``);
  }
});

async function joinChannel(channel) {
  try {
    connection = joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
      selfMute: true,
      selfDeaf: true,
    });

    console.log(``);

    // Connection event listeners
    connection.on('stateChange', (oldState, newState) => {
      console.log(`Connection state changed: ${newState.status}`);
      if (newState.status === 'Disconnected') {
        console.log(`Disconnected from voice channel. Attempting to reconnect in 5 seconds...`);
        setTimeout(async () => {
          try {
            await joinChannel(channel); // Attempt to reconnect
          } catch (error) {
            console.error(`Reconnection failed: ${error}`);
          }
        }, 5000);
      }
    });

    connection.on('error', (error) => {
      console.error(``);
    });

    connection.on('disconnect', (disconnectReason) => {
      console.log(``);
    });
  } catch (error) {
    console.error(``);
  }
}

// Log in the bot
client.login(token);
