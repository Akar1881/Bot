const { Client, GatewayIntentBits } = require('discord.js');
const fs = require('fs');
const mysql = require('mysql2');
const { registerCommands, handleInteraction } = require('./commands/commands');
const { spawn } = require('child_process');
const path = require('path');
const config = JSON.parse(fs.readFileSync('./config.json'));

// Initialize MySQL database connection
const db = mysql.createConnection({
  host: config.dbHost, // e.g., 'localhost'
  user: config.dbUser, // your database username
  password: config.dbPassword, // your database password
  database: config.dbName // your database name
});

// Create necessary tables
db.connect(err => {
  if (err) {
    console.error('Database connection failed:', err);
    return;
  }

  db.query(`CREATE TABLE IF NOT EXISTS config (token VARCHAR(255) PRIMARY KEY, channelId VARCHAR(255), userId VARCHAR(255))`, (err) => {
    if (err) console.error(err);
  });
  db.query(`CREATE TABLE IF NOT EXISTS limits (userId VARCHAR(255) PRIMARY KEY, tokens_limit INT)`, (err) => {
    if (err) console.error(err);
  });
  db.query(`CREATE TABLE IF NOT EXISTS balance (userId VARCHAR(255) PRIMARY KEY, coins INT, lastClaim INT)`, (err) => {
    if (err) console.error(err);
  });
});

// Client initialization
const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers] });

client.once('ready', () => {
  console.log('Main bot is ready!');
  registerCommands();

  // Load existing bot instances
  db.query(`SELECT * FROM config`, (err, rows) => {
    if (err) {
      console.error(err);
      return;
    }

    rows.forEach(({ token, channelId }) => {
      const subBotProcess = spawn('node', [path.join(__dirname, 'subBot.js'), token, channelId]);

      subBotProcess.stdout.on('data', (data) => {
        console.log(`Another Giveaway bot added`);
      });

      subBotProcess.stderr.on('data', (data) => {
        console.error(``);
      });

      subBotProcess.on('close', (code) => {
        console.log(``);
      });
    });
  });
});

client.on('interactionCreate', (interaction) => {
  handleInteraction(interaction, client);
});

// Handle uncaught exceptions and unhandled rejections
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
});
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Log in the bot
client.login(config.token);